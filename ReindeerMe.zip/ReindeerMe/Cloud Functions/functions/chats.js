const functions = require('firebase-functions');
const admin = require('firebase-admin');

exports.handleMessage = functions.database
  .ref('users/{user}/chats/{receiver}/{msgkey}')
  .onCreate(
  (snapshot, context) => {
	const senderId = snapshot.child("sender_id").val();
	if (context.params.user != senderId){return null;} // If cloud functions add the message to the receiver's node, don't trigger again.
	const senderName = snapshot.child("sender_name").val();
	const msgContent = snapshot.child("msg_content").val();
	const receiverId = context.params.receiver;
	const msgKey = context.params.msgkey;

	var msgBrief = msgContent;
	if (msgContent.length > 50){
		msgBrief = msgContent.substring(0,50) + "...";
	}
	
	// Send the message to the receiver's chat node
	const messageObj = {
		sender_name: senderName,
		sender_id: senderId,
		msg_content: msgContent
	};
	console.log('MESSAGEOBJ', messageObj);
	snapshot.ref.parent.parent.parent.parent.child(receiverId).child('chats').child(senderId).child(msgKey).set(messageObj);

	// Get receiver token from database then send data message notification to the user
	admin.database().ref(`/users/${receiverId}/registration_token`).once("value", function(tokenSnapshot) {
		 var regToken = tokenSnapshot.val();
		 var message = {
			 	token : regToken,
				data : {
					fn_call_code: "chat",
					msg_key: msgKey,
					sender_name: senderName,
					sender_id: senderId,
					receiver_id: receiverId,
					msg_content: msgContent
				}
				
		 };  
		 console.log('MESSAGE', message);
		 // Now sending notification to the receiver
		 return admin.messaging().send(message)
		 .then((response) => {
		 // Response is a message ID string.
		 console.log('Successfully sent notification.', response);
		 })
		 .catch((error) => {
		 console.log('Error sending notification: ', error);
		 });
  
	}, function (errorObject) {
	  console.log("Token read failed: " + errorObject.code);
	});

}
);