package com.amr.mineapps.reindeerme.chat_classes;

public class Message {
    private String mText;
    private String mImagePath;
    private byte mSentOrRecieved = 0;
    // For determining message style .. 0 for sent and 1 for received. Default is 0


    public Message(String generalMsg){
        mText = generalMsg;
        mImagePath = generalMsg;
    }
    public Message(String generalMsg, byte sentOrReceived){
        mText = generalMsg;
        mImagePath = generalMsg;
        mSentOrRecieved = sentOrReceived;
    }

    public String getmText(){
        return mText;
    }
    private void setmText(String text){
        mText = text;
    }
    public String getmImagePath(){
        return mImagePath;
    }
    private void setmImagePath(String imagePath){
        mImagePath = imagePath;
    }
    public byte getmSentOrReceived(){return mSentOrRecieved;}
    private void  setmSentOrReceived (byte sentOrRecieved){mSentOrRecieved = sentOrRecieved;}

}
