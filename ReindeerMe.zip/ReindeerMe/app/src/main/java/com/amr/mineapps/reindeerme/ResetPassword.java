package com.amr.mineapps.reindeerme;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.ProviderQueryResult;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class ResetPassword extends AppCompatActivity {

    private FirebaseAuth auth;
    private EditText emailEditText;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        emailEditText = findViewById(R.id.emailTextView);

    }

    public void resetBtnClicked(View v) {
        auth = FirebaseAuth.getInstance();
        userEmail = emailEditText.getText().toString();
        if (userEmail.trim().length() != 0) {
            userEmail = userEmail.trim();
            emailExistenceCheck();
        } else {
            Toast.makeText(this, "Enter an email address!", Toast.LENGTH_LONG).show();
        }
    }

    private void emailExistenceCheck() {
        auth.fetchProvidersForEmail(userEmail).addOnCompleteListener(new OnCompleteListener<ProviderQueryResult>() {
            @Override
            public void onComplete(@NonNull Task<ProviderQueryResult> task) {
                if (task.getResult().getProviders().size() != 0) {
                    reset();
                } else {
                    Toast.makeText(ResetPassword.this, "No such email exists.", Toast.LENGTH_LONG).show();

                }

            }
        });
    }

    private void reset() {
        auth.sendPasswordResetEmail(userEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(ResetPassword.this, "Reset password link has been sent to your email.", Toast.LENGTH_LONG).show();
                    Intent inSignIn = new Intent(ResetPassword.this, SignIn.class);
                    startActivity(inSignIn);
                } else {
                    Toast.makeText(ResetPassword.this, "Error with server.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
