package com.amr.mineapps.reindeerme;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;

import androidx.core.app.NotificationCompat;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import android.util.Log;

import com.amr.mineapps.reindeerme.chat_classes.ChatPage;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class NotificationService extends FirebaseMessagingService {
    private Map<String, String> incomingData;
    public static final int CHAT = 1;
    public static final int ACCEPTED_FRIEND = 2;
    public static final int DELETED_FRIEND = 3;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            if (remoteMessage.getData() != null && currentUser.getUid().equals(remoteMessage.getData().get("receiver_id"))) {
                incomingData = remoteMessage.getData();

                switch (incomingData.get("fn_call_code")) {
                    case "chat":
                        chatReceived();
                        break;
                    case "accept_friend":
                        acceptReceived();
                        break;
                    case "delete_friend":
                        deleteReceived();
                        break;
                }
            } else {
                Log.v("No data received: ", "no user detected");
            }
        }
    }

    // Update token in the database when changed
    @Override
    public void onNewToken(String s) {
        try {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
            ref.child(currentUser.getUid()).child("registration_token").setValue(s);
        } catch (Exception e) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }
    }

    private void chatReceived() {
        String senderId = incomingData.get("sender_id");
        String msgContent = incomingData.get("msg_content");
        String msgKey = incomingData.get("msg_key");

        // Record on local db
        Data workInputData = new Data.Builder()
                .putString("sender_id", senderId)
                .putString("msg_content", msgContent)
                .putString("msg_key", msgKey)
                .putByte("receiver_code", (byte)1) // received
                .putInt("work_code", CHAT)
                .build();
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(RecordWorker.class)
                .setInputData(workInputData)
                .build();
        WorkManager.getInstance(this).enqueue(workRequest);

        if (!ChatPage.isActivityVisible) {
            // Create notification
            Intent inNotifChat = new Intent(this, ChatPage.class);
            inNotifChat.putExtra("sender_name", incomingData.get("sender_name"));
            inNotifChat.putExtra("sender_id", senderId);
            PendingIntent pendingNotifyIntent = PendingIntent.getActivity(this, CHAT, inNotifChat, PendingIntent.FLAG_UPDATE_CURRENT);

            Notification notification = new NotificationCompat.Builder(this, "Chat notification")
                    .setContentTitle(incomingData.get("sender_name"))
                    .setContentText(incomingData.get("msg_content"))
                    .setLights(Color.GREEN, 300, 1000)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setColor(Color.GREEN)
                    .setSound(Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + this.getPackageName() + "/" + R.raw.pop))
                    .setContentIntent(pendingNotifyIntent)
                    .setAutoCancel(true)
                    .build();
            NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.notify(CHAT, notification);
            }
        }
    }

    private void acceptReceived() {
        String acceptorId = incomingData.get("friend_id");
        String acceptorName = incomingData.get("friend_name");

        // Record on local db
        Data workInputData = new Data.Builder()
                .putString("friend_id", acceptorId)
                .putString("friend_name", acceptorName)
                .putInt("work_code", ACCEPTED_FRIEND)
                .build();
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(RecordWorker.class)
                .setInputData(workInputData)
                .build();
        WorkManager.getInstance(this).enqueue(workRequest);

        // Create notification
        Intent inMainActivity = new Intent(this, MainActivity.class);
        PendingIntent pendingNotifyIntent = PendingIntent.getActivity(this, ACCEPTED_FRIEND, inMainActivity, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new NotificationCompat.Builder(this, "Friends notifications")
                .setContentTitle("Friend Accepted!")
                .setContentText(acceptorName + " is now your friend!")
                .setLights(Color.GREEN, 300, 1000)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setSmallIcon(R.drawable.ic_launcher)
                .setColor(Color.GREEN)
                .setSound(Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + this.getPackageName() + "/" + R.raw.pop))
                .setContentIntent(pendingNotifyIntent)
                .setAutoCancel(true)
                .build();
        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(ACCEPTED_FRIEND, notification);
        }
    }

    private void deleteReceived() {
        Data workInputData = new Data.Builder()
                .putString("old_friend_id", incomingData.get("old_friend_id"))
                .putInt("work_code", DELETED_FRIEND)
                .build();
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(RecordWorker.class)
                .setInputData(workInputData)
                .build();
        WorkManager.getInstance(this).enqueue(workRequest);
    }
}
