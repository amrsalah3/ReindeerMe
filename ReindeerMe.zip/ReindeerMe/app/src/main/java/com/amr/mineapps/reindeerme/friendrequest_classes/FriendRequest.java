package com.amr.mineapps.reindeerme.friendrequest_classes;

/**
 * Created by Amr on 24-Jun-19.
 */

public class FriendRequest {

    private int mReqPP;
    private String mReqName;
    private String mReqUid;
    public FriendRequest(int reqPP, String reqName, String reqUid){
        mReqPP = reqPP;
        mReqName = reqName;
        mReqUid = reqUid;
    }

    public int getmReqPP(){
        return mReqPP;
    }
    public String getmReqName(){
        return mReqName;
    }
    public String getmReqUid(){
        return mReqUid;
    }




}
