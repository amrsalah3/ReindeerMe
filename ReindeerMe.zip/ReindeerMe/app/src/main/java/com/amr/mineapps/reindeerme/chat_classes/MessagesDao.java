package com.amr.mineapps.reindeerme.chat_classes;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;


@Dao
public interface MessagesDao {

    @Insert
    void insert(MessageObj messageObj);

    @Query("SELECT * FROM MessageObj;")
    List<MessageObj> getAll();

    @Query("SELECT * FROM MessageObj ORDER BY messageId DESC LIMIT 1;")
    MessageObj getLast();
}
