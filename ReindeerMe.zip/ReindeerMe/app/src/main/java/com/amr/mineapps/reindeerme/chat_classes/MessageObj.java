package com.amr.mineapps.reindeerme.chat_classes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class MessageObj {

    @PrimaryKey (autoGenerate = true)
    private int messageId;

    @ColumnInfo(name = "sender")
    private String senderId;

    @ColumnInfo(name = "message_content")
    private String messageContent;

    @ColumnInfo(name = "time")
    private String timeStamp;

    @ColumnInfo(name = "sent_or_received")
    private byte sentOrReceived;

    @ColumnInfo(name = "status")
    private int status; // Not sent, Sent, Received, Seen


    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public byte getSentOrReceived() {
        return sentOrReceived;
    }

    public void setSentOrReceived(byte sentOrReceived) {
        this.sentOrReceived = sentOrReceived;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}

