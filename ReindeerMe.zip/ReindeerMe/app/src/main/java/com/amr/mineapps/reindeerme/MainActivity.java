package com.amr.mineapps.reindeerme;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amr.mineapps.reindeerme.chat_classes.ChatPage;
import com.amr.mineapps.reindeerme.friendrequest_classes.FriendRequest;
import com.amr.mineapps.reindeerme.friendrequest_classes.FriendRequestAdapter;
import com.amr.mineapps.reindeerme.friends_classes.FriendLocalDB;
import com.amr.mineapps.reindeerme.friends_classes.Friend;
import com.amr.mineapps.reindeerme.friends_classes.FriendsAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.ProviderQueryResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.viewpager.widget.ViewPager;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;


public class MainActivity extends AppCompatActivity {

    public static boolean isActivityVisible = false;
    public static boolean isActivityRunning = false;
    public static FirebaseUser currentUser;
    public static DatabaseReference usersRef;
    public static String currentUserUid;
    public static ViewPagerAdapter viewPagerAdapter;
    public static FriendsAdapter friendsAdapter;
    private ViewPager viewPager;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private ImageView user_pp;
    private String FEID;
    private AlertDialog alertDialog;
    private EditText friendEmailInDialog;
    private TextView friendDispNameInDialog;
    private ImageView friendPPInDialog;
    private Button searchButtonInDialog;
    private Button positiveBtn;
    private DataSnapshot foundUserSnapshot;
    private boolean inPendingFriendReq;
    private FrameLayout frameLayout;
    private ProgressBar progressBar;
    private ArrayList<String> U;
    private ArrayList<FriendRequest> reqArrList;
    private FriendRequestAdapter friendRequestAdapter;
    private ListView reqListView;
    private ListView friendsListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        auth = FirebaseAuth.getInstance();
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                currentUser = firebaseAuth.getCurrentUser();
                if (currentUser == null) { // Go to login
                    Intent inLogin = new Intent(MainActivity.this, SignIn.class);
                    startActivity(inLogin);
                    finish();
                } else {
                    currentUser.reload();
                    currentUserUid = currentUser.getUid();

                    // Sending Registration token to Firebase
                    sendRegToken();

                    viewPagerAdapter = new ViewPagerAdapter(MainActivity.this);
                    viewPager = findViewById(R.id.root_viewpager);
                    viewPager.setAdapter(viewPagerAdapter);

                    listFriends();
                    // List in second page
                    listFriendRequests();
                }
            }
        };

        auth.addAuthStateListener(authStateListener);
    }

    private void sendRegToken() {
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (task.isSuccessful()) {
                            usersRef.child(currentUserUid).child("registration_token").setValue(task.getResult().getToken());
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to send token :(", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void listFriends() {

        final FriendLocalDB db = Room.databaseBuilder(this, FriendLocalDB.class, "USER."+currentUserUid).allowMainThreadQueries().build();
        ArrayList<Friend> friendsLocalList = (ArrayList<Friend>) db.friendDao().getAllFromLatest();
        findViewById(R.id.search_bar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.clearAllTables();
            }
        });

        refreshFriendsAdapter();
        viewPagerAdapter.chatNum = friendsLocalList.size();

        friendsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent inChatPage = new Intent(MainActivity.this, ChatPage.class);
                inChatPage.putExtra("sender_pp", friendsAdapter.getItem(position).getPp());
                inChatPage.putExtra("sender_name", friendsAdapter.getItem(position).getName());
                inChatPage.putExtra("sender_id", friendsAdapter.getItem(position).getUid());
                startActivity(inChatPage);
            }
        });
        friendsListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                createListAlertDialog(friendsAdapter.getItem(position).getUid(), position);
                return true;
            }
        });
    }

    private void listFriendRequests() {
        reqArrList = new ArrayList<>();
        friendRequestAdapter = new FriendRequestAdapter(MainActivity.this, reqArrList);

        U = new ArrayList<>();
        // Query for pending requests in the current user
        usersRef.child(currentUserUid).child("inpendingfriendreq").addValueEventListener(new ValueEventListener() {
            // dataSnapShot = inpendingfriendreq node
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                U.clear();
                reqArrList.clear();
                friendRequestAdapter.setList(reqArrList);

                for (final DataSnapshot reqDataSnapShot : dataSnapshot.getChildren()) {
                    auth.fetchProvidersForEmail(reqDataSnapShot.getValue(String.class)).addOnCompleteListener(new OnCompleteListener<ProviderQueryResult>() {
                        @Override
                        public void onComplete(@NonNull Task<ProviderQueryResult> task) {
                            // Check if the email search is authenticated
                            // Here we use the boolean inPendingFriendReq just for returning a bool val but it's not related to the name
                            if (task.getResult().getProviders().size() != 0) {
                                U.add(reqDataSnapShot.getKey());
                            } else {
                                reqDataSnapShot.getRef().setValue(null);
                            }
                        }
                    });
                    U.add(reqDataSnapShot.getKey());
                }
                usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    // sDataSnapshot = "users" node DataSnapShot
                    @Override
                    public void onDataChange(DataSnapshot sDataSnapshot) {
                        // searchForPendingUserDS = a user from database (child node of "users" node)
                        for (DataSnapshot searchForPendingUserDS : sDataSnapshot.getChildren()) {
                            innerLoop:
                            for (int i = 0, arrLen = U.size(); i < arrLen; i++) {
                                if (searchForPendingUserDS.getKey().equals(U.get(i))) {
                                    reqArrList.add(new FriendRequest(R.drawable.default_pp, searchForPendingUserDS.child("name").getValue(String.class), searchForPendingUserDS.getKey()));
                                    break innerLoop;
                                }
                            }
                        }
                        friendRequestAdapter.setList(reqArrList);
                        reqListView = findViewById(R.id.req_list_view);
                        reqListView.setAdapter(friendRequestAdapter);
                        viewPagerAdapter.reqNum = reqArrList.size();
                        viewPagerAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(MainActivity.this, "Error querying", Toast.LENGTH_SHORT).show();
                    }
                });
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Error querying", Toast.LENGTH_SHORT).show();
            }

        });
    }


    public void addDialogClicked(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add new Friends")
                .setView(this.getLayoutInflater().inflate(R.layout.add_friend_dialog, null))
                .setPositiveButton("ADD", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        //if (usersRef.child(currentUser.getUid()).child("friends").child(foundUserSnapshot.getRef().getKey()) != null) { //if they are not already friends
                        if (!inPendingFriendReq) { // if friend request does not exist, send req
                            foundUserSnapshot.getRef().child("inpendingfriendreq").child(currentUser.getUid()).setValue(currentUser.getEmail());
                            usersRef.child(currentUser.getUid()).child("outpendingfriendreq").child(foundUserSnapshot.getRef().getKey()).setValue(foundUserSnapshot.child("email").getValue());
                            Toast.makeText(MainActivity.this, "Friend request Sent.", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Friend request was already sent!", Toast.LENGTH_LONG).show();


                        }

//                        } else {
//                            Toast.makeText(MainActivity.this, "U are already friends!", Toast.LENGTH_LONG).show();
//                        }


                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });


        alertDialog = builder.create();
        alertDialog.show();

        positiveBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        positiveBtn.setClickable(false);
        positiveBtn.setTextColor(Color.GRAY);

        friendEmailInDialog = alertDialog.findViewById(R.id.email_edittext_indialog);
        searchButtonInDialog = alertDialog.findViewById(R.id.search_btn_indialog);
        friendDispNameInDialog = alertDialog.findViewById(R.id.friend_displayname_indialog);
        friendPPInDialog = alertDialog.findViewById(R.id.friend_PP_indialog);

        searchButtonInDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FEID = friendEmailInDialog.getText().toString(); // FEID : friendEmailInDialog
                if (!TextUtils.isEmpty(friendEmailInDialog.getText()) && Patterns.EMAIL_ADDRESS.matcher(FEID).matches()) {
                    searchForPeopleFunc();
                }

            }
        });
    }


    private void searchForPeopleFunc() {
        if (!FEID.equals(currentUser.getEmail())) {
            auth.fetchProvidersForEmail(FEID).addOnCompleteListener(new OnCompleteListener<ProviderQueryResult>() {
                @Override
                public void onComplete(@NonNull Task<ProviderQueryResult> task) {
                    // Check if the email search is authenticated
                    if (task.getResult().getProviders().size() != 0) {
                        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                                    if (ds.child("email").getValue(String.class).equals(FEID)) { // if the search value matches the email of the snapshot
                                        if (ds.child("inpendingfriendreq").child(currentUser.getUid()).exists()) { // check if there is already friend request sent to him before
                                            inPendingFriendReq = true;
                                        } else {
                                            inPendingFriendReq = false;
                                        }

                                        foundUserSnapshot = ds;

                                        friendEmailInDialog.setVisibility(View.GONE);

                                        friendDispNameInDialog.setText(FEID);
                                        friendDispNameInDialog.setVisibility(View.VISIBLE);

                                        friendPPInDialog.setImageResource(R.drawable.default_pp);
                                        friendPPInDialog.setVisibility(View.VISIBLE);

                                        positiveBtn.setClickable(true);
                                        positiveBtn.setTextColor(Color.parseColor("#FF4081")); //clickable


                                        break;
                                    }

                                }

                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(MainActivity.this, "Error with querying", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Toast.makeText(MainActivity.this, "Not found.", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        } else {
            Toast.makeText(this, "U cannot add yourself!", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (authStateListener != null) {
            auth.removeAuthStateListener(authStateListener);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityVisible = true;
        isActivityRunning = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        isActivityVisible = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        isActivityVisible = false;
        isActivityRunning = false;
        // Remove references to static variables
        friendsAdapter = null;
        currentUser = null;
        currentUserUid = null;
        usersRef = null;
        viewPagerAdapter = null;
    }

    public void accSettings(View v) {
        Intent inAccSettings = new Intent(this, AccSettingsActivity.class);
        startActivity(inAccSettings);
    }

    private void createListAlertDialog(final String uid, final int position) {
        String[] listChoices = {"Unfriend", "Test option"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setItems(listChoices, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    // Unfriend

                    usersRef.child(currentUserUid).child("friends").child(uid).setValue(null);

                    Data workInputData = new Data.Builder()
                            .putString("old_friend_id", friendsAdapter.getItem(position).getUid())
                            .putInt("work_code", NotificationService.DELETED_FRIEND)
                            .build();
                    OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(RecordWorker.class)
                            .setInputData(workInputData)
                            .build();
                    WorkManager.getInstance(MainActivity.this).enqueue(workRequest);

                    Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.create().show();
    }

    private void refreshFriendsAdapter() {
        final FriendLocalDB db = Room.databaseBuilder(this, FriendLocalDB.class, "USER."+currentUserUid).allowMainThreadQueries().build();
        ArrayList<Friend> friendsLocalList = (ArrayList<Friend>) db.friendDao().getAllFromLatest();
        friendsAdapter = new FriendsAdapter(this, friendsLocalList);
        friendsListView = findViewById(R.id.friends_list_view);
        friendsListView.setAdapter(friendsAdapter);
    }
}
