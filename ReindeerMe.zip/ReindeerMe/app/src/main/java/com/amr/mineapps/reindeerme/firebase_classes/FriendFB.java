package com.amr.mineapps.reindeerme.firebase_classes;

/**
 * Created by Amr on 20-Jun-19.
 */

public class FriendFB {

        private String friendEmail;

        public FriendFB(){

        }

        public FriendFB(String friendEmail){
            this.friendEmail = friendEmail;
        }

        public String getFriendEmail(){
            return friendEmail;
        }

        public void setFriendEmail(){
            this.friendEmail = friendEmail;
        }



    }
