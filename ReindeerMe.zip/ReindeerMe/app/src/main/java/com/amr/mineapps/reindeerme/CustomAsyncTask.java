package com.amr.mineapps.reindeerme;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class CustomAsyncTask extends android.os.AsyncTask<String, String, String> {

    private ProgressBar pb;
    private Context mContext;
    private ArrayList<String> U;
    private DatabaseReference usersRef;

    public CustomAsyncTask(Context context) {
        mContext = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pb = new ProgressBar(mContext);
        pb.setVisibility(View.VISIBLE);
        pb.setIndeterminate(true);
        U = new ArrayList<>();
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");
    }

    @Override
    protected String doInBackground(String... strings) {

        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);


    }

}
