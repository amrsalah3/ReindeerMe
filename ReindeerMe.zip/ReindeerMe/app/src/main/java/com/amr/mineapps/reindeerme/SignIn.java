package com.amr.mineapps.reindeerme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.ProviderQueryResult;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SignIn extends AppCompatActivity {

    private FirebaseAuth auth;
    private EditText emailEditText;
    private EditText passwordEditText;
    private String userEmail;
    private String userPassword;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor sharedPreferencesEditor;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        emailEditText = findViewById(R.id.emailTextView);
        passwordEditText = findViewById(R.id.passwordTextView);

    }

    public void loginBtnClicked(View v) {
        progressBar = findViewById(R.id.progress_Bar);
        auth = FirebaseAuth.getInstance();
           userEmail = emailEditText.getText().toString();
           userPassword = passwordEditText.getText().toString();

        if (android.util.Patterns.EMAIL_ADDRESS.matcher(userEmail).matches() && userPassword.length() != 0 ) {
            progressBar.setVisibility(View.VISIBLE);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE , WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE); //prevent user interactions while loading
            emailExistenceCheck(); //email existence check then sign in
        }else{
            Toast.makeText(this, "Type a valid email and password first!", Toast.LENGTH_LONG).show();
        }
    }


    private void emailExistenceCheck(){
        auth.fetchProvidersForEmail(userEmail).addOnCompleteListener(new OnCompleteListener<ProviderQueryResult>() {
            @Override
            public void onComplete(@NonNull Task<ProviderQueryResult> task) {
                if (task.getResult().getProviders().size() != 0) {
                       signIn();
                } else{
                    Toast.makeText(SignIn.this, "This email is not registered.", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);//interactions back again
                }
            }
        });
    }


    public void signIn(){
        auth.signInWithEmailAndPassword(userEmail,userPassword)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressBar.setVisibility(View.GONE);
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);//interactions back again
                        if(task.isSuccessful()){
                            Toast.makeText(SignIn.this, "Welcome!", Toast.LENGTH_SHORT).show();
                            Intent inMainActivity = new Intent(SignIn.this, MainActivity.class);
                            inMainActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(inMainActivity);
                            finish();
                        }else{
                            Toast.makeText(SignIn.this, "There is something wrong with your email or password", Toast.LENGTH_LONG).show();
                        }
                    }
                });


    }




    public void GoToSignUp(View v){
        Intent SignUp = new Intent(this,SignUp.class);
        startActivity(SignUp);

    }
    public void  ForgotPassFun(View v){
        Intent inResetPassword = new Intent(this,ResetPassword.class);
        startActivity(inResetPassword);
    }

   /** @Override
    protected void onPause() {
        super.onPause();
        userEmail = emailEditText.getText().toString();

        sharedPreferencesEditor = getSharedPreferences("SaveTypedEmail",MODE_PRIVATE).edit();
        sharedPreferencesEditor.putString("TypedEmail",userEmail);
        sharedPreferencesEditor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sharedPreferences = getSharedPreferences("SaveTypedEmail",MODE_PRIVATE);
        userEmail = sharedPreferences.getString("TypedEmail","");
        emailEditText.setText(userEmail);
    }**/















}
