package com.amr.mineapps.reindeerme;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class AccSettingsActivity extends AppCompatActivity {

    Intent inSignInActivity;
    FirebaseAuth auth;
    FirebaseUser currentUser;
    FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acc_settings);
    }

    public void signOut(View v) {
        implementations();
        auth.addAuthStateListener(authStateListener);
        auth.signOut();
    }

    public void deleteAcc(View v) {
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users");
        implementations();
        // Remove friend requests sent to/from other users
        ref.child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.child("outpendingfriendreq").getChildren()) {
                    ref.child(ds.getKey()).child("inpendingfriendreq").child(currentUser.getUid()).setValue(null);
                }
                for (DataSnapshot ds : dataSnapshot.child("inpendingfriendreq").getChildren()) {
                    ref.child(ds.getKey()).child("outpendingfriendreq").child(currentUser.getUid()).setValue(null);
                }
                ref.child(currentUser.getUid()).setValue(null); // Delete account info from the database
                auth.addAuthStateListener(authStateListener);
                currentUser.delete(); // Delete authentication
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(AccSettingsActivity.this, "Error with deleting account.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void implementations() {
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        inSignInActivity = new Intent(this, SignIn.class);
        inSignInActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser() == null){
                    Log.v("CCCCC", "DONE");
                    auth.removeAuthStateListener(authStateListener);
                    startActivity(inSignInActivity);
                    finish();
                }else{
                    firebaseAuth.getCurrentUser().reload();
                    Log.v("CCCCC", "not yet");
                }
            }
        };
    }

}
