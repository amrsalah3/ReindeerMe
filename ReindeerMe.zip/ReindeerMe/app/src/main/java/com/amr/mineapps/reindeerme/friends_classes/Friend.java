package com.amr.mineapps.reindeerme.friends_classes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Friend {

    @PrimaryKey(autoGenerate = true)
    int friendId;

    @ColumnInfo(name = "pp")
    int pp;

    @ColumnInfo(name = "name")
    String name;

    @ColumnInfo(name = "uid")
    String uid;

    public Friend(){

    }

    public Friend(int pp, String name, String uid){
        this.pp = pp;
        this.name = name;
        this.uid = uid;
    }


    public int getFriendId() {
        return friendId;
    }

    public void setFriendId(int friendId) {
        this.friendId = friendId;
    }

    public int getPp() {
        return pp;
    }

    public void setPp(int pp) {
        this.pp = pp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }


}

