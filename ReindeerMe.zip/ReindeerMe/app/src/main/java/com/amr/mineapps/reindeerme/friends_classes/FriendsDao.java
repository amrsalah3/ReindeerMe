package com.amr.mineapps.reindeerme.friends_classes;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;


@Dao
public interface FriendsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Friend friendObj);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List <Friend> list);

    @Query("SELECT * FROM Friend;")
    List<Friend> getAll();

    @Query("SELECT * FROM Friend ORDER BY friendId DESC;")
    List<Friend> getAllFromLatest();

    @Query("SELECT * FROM Friend ORDER BY friendId DESC LIMIT 1;")
    Friend getLast();

    @Query("SELECT * FROM Friend WHERE uid = :id")
    Friend queryFriendObj(String id);

    @Delete
    void remove(Friend friendObj);
}

