package com.amr.mineapps.reindeerme.chat_classes;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.amr.mineapps.reindeerme.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * Created by Amr on 09-Aug-19.
 */

public class MessageAdapter extends ArrayAdapter<Message> {
    private Context mContext;
    private ArrayList<Message> mList = new ArrayList<>();
    private RelativeLayout.LayoutParams receiverParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    private RelativeLayout.LayoutParams senderParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);

    public MessageAdapter(Context context, ArrayList<Message> list) {
        super(context, 0, list);
        mContext = context;
        mList = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;

        if (convertView == null) {
            itemView = LayoutInflater.from(mContext).inflate(R.layout.message_item, parent, false);
        }

        Message message = mList.get(position);
        // Set message layout style (alignment and color) for sending or receiving message
        senderParams.addRule(RelativeLayout.ALIGN_PARENT_END);
        receiverParams.addRule(RelativeLayout.ALIGN_PARENT_START);

        ConstraintLayout constraintLayout = itemView.findViewById(R.id.message_layout);
        // Change background color of the layout (which is the "rounded_corners.xml" drawable)
        GradientDrawable messageBackground = (GradientDrawable) constraintLayout.getBackground();

        TextView textView = itemView.findViewById(R.id.msg_tv);
        TextView messageStatus = itemView.findViewById(R.id.message_status_tv);

        if (message.getmSentOrReceived() == 0) {
            // If the message is sent
            messageBackground.setColor(Color.parseColor("#B00020"));
            constraintLayout.setLayoutParams(senderParams);
        } else {
            // Otherwise the message is received, Change style!
            messageBackground.setColor(Color.parseColor("#000000"));
            constraintLayout.setLayoutParams(receiverParams);
        }
        textView.setVisibility(View.VISIBLE);
        textView.setText(message.getmText());
        messageStatus.setVisibility(View.VISIBLE);
        messageStatus.setText("test");
        //ImageView imageView = itemView.findViewById(R.id.msg_image);
        //imageView.setImage;
        return itemView;
    }
}
