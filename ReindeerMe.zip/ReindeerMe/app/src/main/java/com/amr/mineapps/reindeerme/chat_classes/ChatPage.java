package com.amr.mineapps.reindeerme.chat_classes;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.amr.mineapps.reindeerme.MainActivity;
import com.amr.mineapps.reindeerme.NotificationService;
import com.amr.mineapps.reindeerme.R;
import com.amr.mineapps.reindeerme.RecordWorker;
import com.amr.mineapps.reindeerme.SignIn;
import com.amr.mineapps.reindeerme.friends_classes.Friend;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class ChatPage extends AppCompatActivity {
    EditText editText;
    String messageOfEditText;
    ImageView imageView;
    String imagePath;
    public static boolean isActivityVisible = false;
    public static boolean isActivityRunning = false;
    public static final int PENDING = 0, SENT = 1, DELIVERED = 2, SEEN = 3;
    public static final byte RECEIVER_CODE = 1;
    public static String chatID;
    public static MessageAdapter msgAdapter;
    private ArrayList<Message> arrList;
    private ListView msgsListView;
    private ChatLocalDB db;
    private MessageObj messageObj;
    private int triggerNum = 0;
    private FirebaseUser currentUser;
    private String currentUserUid;
    private DatabaseReference usersRef;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_page);

        auth = FirebaseAuth.getInstance();
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                currentUser = firebaseAuth.getCurrentUser();
                if (currentUser == null) {
                    Intent inSignIn = new Intent(ChatPage.this, SignIn.class);
                    startActivity(inSignIn);
                    finish();
                } else {
                    currentUser.reload();
                    currentUserUid = currentUser.getUid();

                    setTitle(getIntent().getExtras().getString("sender_name"));
                    chatID = getIntent().getExtras().getString("sender_id");

                    usersRef = FirebaseDatabase.getInstance().getReference().child("users");

                    arrList = new ArrayList<>();
                    msgsListView = findViewById(R.id.messagesListView);

                    // Receive messages from the local database
                    viewSavedLocalMessages();

                    // Receiving all messages from database to the app
                    listenerForUpcomingMessages();
                }
            }
        };
        auth.addAuthStateListener(authStateListener);
    }

    private void viewSavedLocalMessages() {
        db = Room.databaseBuilder(getApplicationContext(), ChatLocalDB.class, currentUserUid+chatID).allowMainThreadQueries().build();
        messageObj = new MessageObj();
        ArrayList<MessageObj> localMsgsList = (ArrayList<MessageObj>) db.messagesDao().getAll();
        for (int i = 0, n = localMsgsList.size(); i < n; i++) {
            MessageObj current = localMsgsList.get(i);
            if (current.getSentOrReceived() == 0) { // If own message
                arrList.add(new Message(current.getMessageContent()));
            } else { // Otherwise recipient
                arrList.add(new Message(current.getMessageContent(), RECEIVER_CODE));
            }
        }

        msgAdapter = new MessageAdapter(this, arrList);
        msgsListView.setAdapter(msgAdapter);
    }

    private void listenerForUpcomingMessages() {

/**
 if (usersRef.child(currentUserUid).child("chats").child(chatID) == null) {
 // Chat is empty. So, start listening from next
 triggerNum = 1;
 }
 usersRef.child(currentUserUid)
 .child("chats").child(chatID).limitToLast(1).addChildEventListener(new ChildEventListener() {
@Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
// Don't apply those changes when listener once registered (when triggerNum = 0)
if (triggerNum != 0) {
// If the underlying message was sent by the current user
if (dataSnapshot.child(currentUserUid).exists()) {
// DON'T DO ANYTHING UNTIL NOW.
} else { // Otherwise was sent by the other person
messageObj.setMessageContent(dataSnapshot.child(chatID).getValue(String.class));
messageObj.setSenderId(chatID);
messageObj.setSentOrReceived(RECEIVER_CODE);
messageObj.setStatus(DELIVERED);
db.messagesDao().insert(messageObj);
msgAdapter.add(new Message(dataSnapshot.child(chatID).getValue(String.class), RECEIVER_CODE));
}
} else {
triggerNum = 1; // It's ok for the coming triggers to apply changes to local db
}

}

@Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {

}

@Override public void onChildRemoved(DataSnapshot dataSnapshot) {

}

@Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {

}

@Override public void onCancelled(DatabaseError databaseError) {
Toast.makeText(ChatPage.this, "Error receiving message", Toast.LENGTH_SHORT).show();
}
}); **/
    }


    public void OpenGallery(View view) {
        //Intent pickImageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        /**Intent pickImageIntent = new Intent(Intent.ACTION_GET_CONTENT);
         pickImageIntent.setType("image/*");
         startActivityForResult(pickImageIntent, 0);**/
        db.clearAllTables();
        usersRef.child(currentUserUid)
                .child("chats").child(chatID).setValue(null);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 0) {
                Uri uri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    StorageReference storageRef = FirebaseStorage.getInstance().getReference();
                    storageRef.child("Profile Pictures").child("1").putFile(uri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    Toast.makeText(ChatPage.this, "Done uploading..", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(ChatPage.this, "Error uploading..", Toast.LENGTH_SHORT).show();
                                }
                            });
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }

    }

    public void sendMsgFunc(View view) {
        editText = findViewById(R.id.typeMessage);
        messageOfEditText = editText.getText().toString();
        int txtLength = messageOfEditText.length();
        while (messageOfEditText.charAt(txtLength - 1) == ' ') {
            // While there is a white space at the end of the text, delete it!
            messageOfEditText = messageOfEditText.substring(0, txtLength - 1);
            txtLength--;
        }
        if (messageOfEditText.trim().length() > 0) {
            // Send that message
            Map<String, Object> uploadMsg = new HashMap<>();
            uploadMsg.put("sender_id", currentUserUid);
            uploadMsg.put("sender_name", currentUser.getDisplayName());
            uploadMsg.put("msg_content", messageOfEditText);
            uploadMsg.put("msg_status", SENT);
            usersRef.child(currentUserUid).child("chats").child(chatID).push().setValue(uploadMsg).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(ChatPage.this, "Success", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(ChatPage.this, "Fail", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            Data workInputData = new Data.Builder()
                    .putString("msg_content", messageOfEditText)
                    .putString("sender_id", chatID) // Sender is current user but the key name is sender_id because used like that name among many fields **DON'T CHANGE IT!!**
                    .putInt("work_code", NotificationService.CHAT)
                    .build();
            OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(RecordWorker.class)
                    .setInputData(workInputData)
                    .build();
            WorkManager.getInstance(this).enqueue(workRequest);



        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (authStateListener != null) {
            auth.removeAuthStateListener(authStateListener);
        }

        try {
            EditText editText = findViewById(R.id.typeMessage);
            SharedPreferences.Editor sharedPreferencesEditor = getSharedPreferences("save_chat_text", MODE_PRIVATE).edit();
            sharedPreferencesEditor.putString("text", editText.getText().toString());
            sharedPreferencesEditor.apply();
        } catch (Exception e) {
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityVisible = true;
        isActivityRunning = true;
        SharedPreferences sharedPreferencesEditor = getSharedPreferences("save_chat_text", MODE_PRIVATE);
        EditText editText = findViewById(R.id.typeMessage);
        editText.setText(sharedPreferencesEditor.getString("text", ""));
    }

    @Override
    protected void onStop() {
        super.onStop();
        isActivityVisible = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isActivityVisible = false;
        isActivityRunning = false;
        // Remove reference to static adapter
        msgAdapter = null;
    }
}
