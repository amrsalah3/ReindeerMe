package com.amr.mineapps.reindeerme.friends_classes;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Friend.class}, version = 2, exportSchema = false )
public abstract class FriendLocalDB extends RoomDatabase {
    public abstract FriendsDao friendDao();
}

