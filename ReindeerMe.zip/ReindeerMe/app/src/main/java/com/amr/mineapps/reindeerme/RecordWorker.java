package com.amr.mineapps.reindeerme;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.amr.mineapps.reindeerme.chat_classes.ChatLocalDB;
import com.amr.mineapps.reindeerme.chat_classes.ChatPage;
import com.amr.mineapps.reindeerme.chat_classes.Message;
import com.amr.mineapps.reindeerme.chat_classes.MessageObj;
import com.amr.mineapps.reindeerme.friends_classes.FriendLocalDB;
import com.amr.mineapps.reindeerme.friends_classes.Friend;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


import androidx.annotation.NonNull;
import androidx.room.Room;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class RecordWorker extends Worker {
    private String FriendsDbId;
    private String currentUserUid;
    private FirebaseUser currentUser;

    public RecordWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        // Check if the receiver is not the current user
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            return Result.failure();
        }
        currentUserUid = currentUser.getUid();
        FriendsDbId = "USER." + currentUserUid;
        switch (getInputData().getInt("work_code", 0)) {

            case NotificationService.CHAT:
                addChatDB();
                break;
            case NotificationService.ACCEPTED_FRIEND:
                addFriendToDB();
                break;
            case NotificationService.DELETED_FRIEND:
                deleteFriendFromDB();
                break;
        }
        return Result.success();
    }

    private void addChatDB() {
        // Update chat database
        final String msgContent = getInputData().getString("msg_content");
        final String senderId = getInputData().getString("sender_id");
        final byte sentOrReceived = getInputData().getByte("receiver_code", (byte) 0);
        // Record Chat on local Db
        ChatLocalDB db = Room.databaseBuilder(getApplicationContext(), ChatLocalDB.class, currentUserUid+senderId).build();
        final MessageObj messageObj = new MessageObj();
        messageObj.setMessageContent(msgContent);
        messageObj.setSenderId(senderId);
        messageObj.setSentOrReceived(sentOrReceived);
        messageObj.setStatus(ChatPage.DELIVERED);
        db.messagesDao().insert(messageObj);

        // Update friends database

        final Friend friend = MainActivity.friendsAdapter.getFriendObjByUid(senderId);
        final FriendLocalDB friendLocalDB = Room.databaseBuilder(getApplicationContext(), FriendLocalDB.class, FriendsDbId).build();
        final Friend friendInDB = friendLocalDB.friendDao().queryFriendObj(senderId);
        // Update friends db order
        friendLocalDB.runInTransaction(new Runnable() {
            @Override
            public void run() {
                // Remove him from his position in db, then insert him (a new object) at the end of the db (as latest friend activity)
                friendLocalDB.friendDao().remove(friendInDB);
                friendLocalDB.friendDao().insert(new Friend(friend.getPp(),friend.getName(),friend.getUid()));
            }
        });
        // Update UI list
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    // Refresh chat page
                    if (ChatPage.isActivityRunning) {
                        ChatPage.msgAdapter.add(new Message(messageObj.getMessageContent(), messageObj.getSentOrReceived()));
                    Log.v("AAAAAAAAAAA","AAAAAAAAAA");
                    }
                    // Update main activity friends list order and bring him to top (0-index)
                    if (MainActivity.isActivityRunning) {
                        MainActivity.friendsAdapter.remove(friend);
                        MainActivity.friendsAdapter.insert(friend, 0);
                    }
                }
            });
        } catch (Exception e) {
        }


    }

    private void addFriendToDB() {
        FriendLocalDB friendLocalDB = Room.databaseBuilder(getApplicationContext(), FriendLocalDB.class, FriendsDbId).build();
        final Friend friend = new Friend(R.drawable.default_pp, getInputData().getString("friend_name"), getInputData().getString("friend_id"));
        friendLocalDB.friendDao().insert(friend);

        // Update UI list
        if (MainActivity.isActivityRunning) {
            try {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.friendsAdapter.insert(friend, 0);
                        MainActivity.viewPagerAdapter.chatNum++;
                        MainActivity.viewPagerAdapter.notifyDataSetChanged();
                    }
                });
            } catch (Exception e) {
            }
        }
    }

    private void deleteFriendFromDB() {
        final FriendLocalDB friendLocalDB = Room.databaseBuilder(getApplicationContext(), FriendLocalDB.class, FriendsDbId).build();
        final Friend friendInDb = friendLocalDB.friendDao().queryFriendObj(getInputData().getString("old_friend_id"));
        if (friendInDb != null) {
            friendLocalDB.friendDao().remove(friendInDb);
        }
        // Update UI list
        if (MainActivity.isActivityRunning) {
            try {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (friendInDb != null) {
                        Friend friendInAdapter = MainActivity.friendsAdapter.getFriendObjByUid(getInputData().getString("old_friend_id"));
                        MainActivity.friendsAdapter.remove(friendInAdapter);
                        MainActivity.viewPagerAdapter.chatNum--;
                        MainActivity.viewPagerAdapter.notifyDataSetChanged();
                    }
                }
            });
        } catch(Exception e){
            Log.v("AAAAAAAAAAAAA", "ERROR");
        }
    }
}
}