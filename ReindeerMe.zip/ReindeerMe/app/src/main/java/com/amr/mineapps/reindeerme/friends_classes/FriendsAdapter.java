package com.amr.mineapps.reindeerme.friends_classes;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.amr.mineapps.reindeerme.CustomAsyncTask;
import com.amr.mineapps.reindeerme.MainActivity;
import com.amr.mineapps.reindeerme.R;
import com.amr.mineapps.reindeerme.chat_classes.ChatLocalDB;
import com.amr.mineapps.reindeerme.chat_classes.ChatPage;
import com.amr.mineapps.reindeerme.chat_classes.Message;
import com.amr.mineapps.reindeerme.chat_classes.MessageObj;

import org.w3c.dom.Text;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Room;


public class FriendsAdapter extends ArrayAdapter<Friend> {

    private Context mContext;
    private List<Friend> mList;
    private ChatLocalDB chatLocalDB;

    public FriendsAdapter(Context context, ArrayList<Friend> arrList) {
        super(context, 0, arrList);
        mContext = context;
        mList = arrList;
    }

    public void setList(ArrayList<Friend> arrList) {
        new FriendsAdapter(mContext,arrList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;
        if (convertView == null) {
            itemView = LayoutInflater.from(mContext).inflate(R.layout.friends_list_item, parent, false);
        }

        final Friend friend = mList.get(position);

        ImageView ppView = itemView.findViewById(R.id.friend_pic);
        ppView.setImageResource(friend.getPp());

        TextView nameView = itemView.findViewById(R.id.friend_name);
        nameView.setText(friend.getName());

        // Display last message under name of the friend
        TextView lastMsgView = itemView.findViewById(R.id.last_msg);
        chatLocalDB = Room.databaseBuilder(mContext, ChatLocalDB.class, MainActivity.currentUserUid+friend.getUid()).build();
        new LastMsgAsyncTask(lastMsgView, chatLocalDB).execute();

        return itemView;
    }


    private static class LastMsgAsyncTask extends AsyncTask<Void, Void, MessageObj>{

        private WeakReference<TextView> weakReference;
        private ChatLocalDB c;
        private LastMsgAsyncTask(TextView textView, ChatLocalDB c){
            weakReference = new WeakReference<>(textView);
            this.c = c;
        }
        @Override
        protected MessageObj doInBackground(Void... params) {

            return c.messagesDao().getLast();
        }

        @Override
        protected void onPostExecute(MessageObj obj) {
            if (obj == null){return;}
            String s = obj.getMessageContent();
            if (s.length() > 30){
                s = s.substring(0, 30) + "...";
            }
            // Set last message to the TextView
            if (obj.getSentOrReceived()== ChatPage.RECEIVER_CODE){
                weakReference.get().setText(s);
            }else{
                s = "You: " + s;
                weakReference.get().setText(s);
            }

        }
    }


    public Friend getFriendObjByUid(String uid){
        Friend obj;
        for (int i = 0, x = mList.size(); i < x; i++){
            obj = mList.get(i);
            if (obj.getUid().equals(uid)){
                return obj;
            }
        }
        return null;
    }
}
