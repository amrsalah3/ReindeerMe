package com.amr.mineapps.reindeerme.chat_classes;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {MessageObj.class}, version = 2, exportSchema = false )
public abstract class ChatLocalDB extends RoomDatabase {
    public abstract MessagesDao messagesDao();
}
